-- KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
-- This file configures optional live Supabase accounts, orders and notifications.
-- KO TECH database setup for Supabase SQL Editor.
-- PUBLIC client uses publishable key + signed-in session; no service role key in website.
-- Product prices in ZAR cents are recalculated here, NEVER trusted from browser totals.

-- Use PostgreSQL crypto helpers for secure identifiers.
create extension if not exists pgcrypto;

-- Define a database table with documented fields and constraints.
create table if not exists public.ko_products (
  id text primary key,
  name text not null,
  image text not null,
  price integer not null check (price >= 0),
  max_quantity integer not null default 10 check (max_quantity between 1 and 100)
);

-- Seed the server catalogue; server prices must match displayed prices.
insert into public.ko_products(id,name,image,price,max_quantity) values
  ('KT-001','VRURC 10000mAh Power Bank Built-in Cables','Images/accessories/product_image_08.jpg',180000,10),
  ('KT-002','LED Cube Bluetooth Speaker','Images/accessories/this-led-cube-bluetooth-speaker-has-style.jpg',490000,10),
  ('KT-003','Tech accessories collection','Images/accessories/the-28-best-tech-gifts-are-perfect-for-anyone-on-your-list.jpg',174000,10),
  ('KT-004','Ulanzi V6 Wireless Lavalier Microphone System','Images/accessories/new-product.avif',290000,10),
  ('KT-005','Sony ICD-UX560 Digital Voice Recorder','Images/accessories/sony-grabadora-de-voz-digital-est-reo-icdux560blk-con-usb-integrado.jpg',245000,10),
  ('KT-006','Compact Microphone','Images/accessories/product-5.jpg',240000,10),
  ('KT-007','Portable Phone Charger 5000mah Power Bank','Images/accessories/portable-phone-charger-5000mah-power-bank-color-black-size-os.jpg',150000,10),
  ('KT-008','Omni 20+ Bundle AC_DC_USBC Power Bank','Images/accessories/product_image_13.jpg',300000,10),
  ('KT-009','iPhone Fast Charger Cable','Images/accessories/product_image_12.jpg',290000,10),
  ('KT-010','Fingerprint USB3','Images/accessories/product_image_10.jpg',1200000,10),
  ('KT-011','SanDisk USB','Images/accessories/product-1.jpg',50000,10),
  ('KT-012','Fitness Tracker','Images/accessories/the-smartest-fitness-tracker-for-people-who-hate-smartwatches.jpg',232000,10),
  ('KT-013','PlayStation DualSense Wireless Controller','Images/gaming/playstation-dualsense-wireless-controller-o-cosmic-red.jpg',190000,10),
  ('KT-014','Sony DualSense Hyperpop Controller','Images/gaming/controle-sem-fio-sony-dualsense-hyperpop-para-ps5-vermelho-techno-red.jpg',290000,10),
  ('KT-015','DualSense Wireless Controller','Images/gaming/dualsense-wireless-controller.jpg',200000,10),
  ('KT-016','AGM Kids Night Vision Goggles','Images/accessories/agm-kids-night-vision-goggles-adjustable-spy-gear-night-mission-goggles-with.jpg',200000,10),
  ('KT-017','[2 Pack] INIU Portable Charger','Images/accessories/product_image_11.jpg',300000,10),
  ('KT-018','NASA Artemis DIY Smartwatch Kit','Images/accessories/nasa-artemis-diy-smartwatch-kit-learn-coding-electronics-wearable-tech-stem.jpg',380000,10),
  ('KT-019','HP 640 G5 Laptop, Core i5-8265U','Images/computer/hp-640-g5-laptop-core-i5-8265u-1-6ghz-16gb-512gb-nvme-14-hd-windows-11-pro-6.jpg',1800000,10),
  ('KT-020','Apple MacBook','Images/computer/mac-book.jpg',2190000,10),
  ('KT-021','Desktop Computer','Images/computer/find-the-perfect-desktop-computer-staples.jpg',2190000,10),
  ('KT-022','Apple Desktop Computer','Images/computer/apple-pc.jpg',3290000,10),
  ('KT-023','Hp Elitebook 830 G8 Intel Core I5-1135g7 16gb','Images/computer/hp-elitebook-830-g8-intel-core-i5-1135g7-16gb-ram-512gb-ssd-13-3-fhd-windows.jpg',3450000,10),
  ('KT-024','HP-123','Images/computer/HP-123.webp',1600000,10),
  ('KT-025','HP computer','Images/computer/hp-pc.jpg',2700000,10),
  ('KT-026','Dell Optiplex 9020 Desktop Computer','Images/computer/dell-optiplex-9020-desktop-computer.jpg',1974000,10),
  ('KT-027','Apple 2024 iMac All-in-One Desktop Computer','Images/computer/apple-2024-imac-all-in-one-desktop-computer-with-m4-chip.jpg',4290000,10),
  ('KT-028','Lenovo Desktop Computer','Images/computer/lenova-pc.jpg',1290000,10),
  ('KT-029','HP new pc','Images/computer/new-pc.webp',1350000,10),
  ('KT-030','HP computer pc','Images/computer/pc.jpg',1080000,10),
  ('KT-031','Apple AirPods Max Wireless Over-Ear Headphones','Images/headphone/apple-airpods-max-wireless-over-ear-headphones.jpg',400000,10),
  ('KT-032','Bluetooth Wireless Over Ear HiFi','Images/headphone/bluetooth-wireless-over-ear-hifi-headphones-with-drivers-black.jpg',290000,10),
  ('KT-033','JBL Tune 700BT Wireless Bluetooth Over-Ear','Images/headphone/jbl-tune-700bt-wireless-bluetooth-over-ear-headphones-with-up-to-27-hours-of.jpg',690000,10),
  ('KT-034','MOVSSOU E7 Active Noise Cancelling Headphones Bluetooth Over Ear','Images/headphone/product_image_05.jpg',390000,10),
  ('KT-035','Headphones Bluetooth','Images/headphone/this-headphones-will-be-very-good.jpg',120000,10),
  ('KT-036','Wireless Over Ear Bluetooth Headphones','Images/headphone/wireless-over-ear-bluetooth-headphones.jpg',300000,10),
  ('KT-037','Baseus Wireless Earbuds','Images/earpod/Baseus.jpg',200000,10),
  ('KT-038','Anker Life P2 Mini True-Wireless Earbuds','Images/earpod/soundcore-by-anker-life-p2-mini-true-wireless-earbuds-in-ear-kopfh-arer-sale.jpg',351000,10),
  ('KT-039','AirPods Pro 3','Images/earpod/buy-airpods-pro-3.jpg',350000,10),
  ('KT-040','Wireless Earbuds','Images/earpod/gallery-B1.jpg',150000,10),
  ('KT-041','realme Buds T310 True Wireless in-Ear Earbuds','Images/earpod/product_image_14.jpg',250000,10),
  ('KT-042','Beats Studio Buds True Wireless Bluetooth Earbuds','Images/earpod/beats-studio-buds-true-wireless-bluetooth-earbuds-black-walmart-com.jpg',300000,10),
  ('KT-043','Dowinx Gaming Chair Ergonomic Racing Style','Images/gaming/gaming-set.jpg',2700000,10),
  ('KT-044','PlayStation 4 limited Edition','Images/gaming/playstation-4.jpg',3890000,10),
  ('KT-045','Oculus Quest 2VR Headset','Images/gaming/meta-quest-3.jpg',1590000,10),
  ('KT-046','XBOX 360 original','Images/gaming/i-have-so-much-fun-with-this-thing-it-s-a-great-time-waster.jpg',2200000,10),
  ('KT-047','GTR Gaming Setup','Images/gaming/gtr-setting.jpg',10050000,10),
  ('KT-048','PlayStation 5 Console','Images/gaming/ps-5.jpg',1800000,10),
  ('KT-049','iPhone 16 256GB in Ultramarine','Images/smartphone/iphone-16-128gb-in-ultramarine-6-1-inch-super-retina-xdr-display-apple.jpg',1128000,10),
  ('KT-050','iPhone 16 128GB in Pink','Images/smartphone/iphone-16-128gb-in-pink-6-1-inch-super-retina-xdr-display-apple.jpg',1790000,10),
  ('KT-051','iPhone 16 128GB in Ultramarine','Images/smartphone/iphone-16-128gb-in-ultramarine-6-1-inch-super-retina-xdr-display-apple.jpg',1750000,10),
  ('KT-052','iPhone 17 Pro 256GB in Cosmic Orange','Images/smartphone/iphone-17-pro-256gb-in-cosmic-orange-apple.jpg',2650000,10),
  ('KT-053','iPhone 17 Pro Max 256GB in Deep Blue','Images/smartphone/iphone-17-pro-max-256gb-in-deep-blue-apple.jpg',2650000,10),
  ('KT-054','iPhone Air 256GB in Light Gold','Images/smartphone/iphone-air-256gb-in-light-gold-6-5-inch-display-apple.jpg',1900000,10),
  ('KT-055','Luxury Apple Watch','Images/watch/smart-watch-for-android-phones-ios.jpg',700000,10),
  ('KT-056','Apple Watch SE3','Images/watch/apple-watch-se3-gps-40-mm-smart-fitness-companion-workout-partner-stylish-sm.jpg',690000,10),
  ('KT-057','Polaroid Single Touch Active Fitness Watch','Images/watch/best-budget-smartwatches-in-2026-top-cheap-fitness-trackers.jpg',390000,10),
  ('KT-058','Apple Watch - Rose','Images/watch/apple-watch-color-rosa-beb-original.jpg',750000,10),
  ('KT-059','Apple Watch Series 11','Images/watch/apple-watch-series-11.jpg',750000,10),
  ('KT-060','Samsung Watch For Men','Images/watch/apple-watch-men.jpg',600000,10),
  ('KT-061','iPhone 18 Pro Max','Images/iphone-18-pro-max-1.jpg',6000000,10),
  ('KT-062','Gaming Total Set','Images/gaming/gaming-set.jpg',9500000,10)
on conflict (id) do update set name=excluded.name,image=excluded.image,price=excluded.price,max_quantity=excluded.max_quantity;

-- Define a database table with documented fields and constraints.
create table if not exists public.ko_orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null default ('KOT-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,12))),
  user_id uuid not null references auth.users(id) on delete cascade,
  request_key text not null,
  created_at timestamptz not null default now(),
  customer jsonb not null,
  items jsonb not null,
  subtotal integer not null check(subtotal >= 0),
  discount integer not null default 0 check(discount >= 0),
  shipping integer not null check(shipping >= 0),
  total integer not null check(total >= 0),
  delivery text not null check(delivery in ('standard','express')),
  promo text not null default '',
  notes text not null default '',
  status text not null default 'Received' check(status in ('Received','Confirmed','Packed','Shipped','Delivered','Cancelled')),
  payment_status text not null default 'Not charged',
  payment_method text not null default 'Arrange with store after confirmation',
  history jsonb not null default '[]'::jsonb,
  unique(user_id,request_key)
);
-- Optimize frequently queried order and notification records.
create index if not exists ko_orders_by_user on public.ko_orders(user_id,created_at desc);

-- Define a database table with documented fields and constraints.
create table if not exists public.ko_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  order_number text,
  title text not null,
  message text not null,
  created_at timestamptz not null default now(),
  read_at timestamptz
);
-- Optimize frequently queried order and notification records.
create index if not exists ko_notifications_by_user on public.ko_notifications(user_id, created_at desc);

-- Define a database table with documented fields and constraints.
create table if not exists public.ko_wishlists (
  user_id uuid primary key references auth.users(id) on delete cascade,
  product_ids text[] not null default '{}'::text[]
);

-- Close direct writes to order and notification tables. All prices/statuses are server-side.
-- Apply row-level security and database restrictions.
alter table public.ko_products enable row level security;
-- Apply row-level security and database restrictions.
alter table public.ko_orders enable row level security;
-- Apply row-level security and database restrictions.
alter table public.ko_notifications enable row level security;
-- Apply row-level security and database restrictions.
alter table public.ko_wishlists enable row level security;
revoke all on table public.ko_products, public.ko_orders, public.ko_notifications, public.ko_wishlists from anon,authenticated;
grant select on table public.ko_products to anon,authenticated;
grant select on table public.ko_orders to authenticated;
grant select on table public.ko_notifications to authenticated;
grant update(read_at) on public.ko_notifications to authenticated;
grant select, insert, update on table public.ko_wishlists to authenticated;

drop policy if exists "Public product catalog" on public.ko_products;
-- Row-level security rule: restrict what each account can access.
create policy "Public product catalog" on public.ko_products for select to anon,authenticated using (true);
drop policy if exists "Customers read own orders" on public.ko_orders;
-- Row-level security rule: restrict what each account can access.
create policy "Customers read own orders" on public.ko_orders for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Customers see own notifications" on public.ko_notifications;
-- Row-level security rule: restrict what each account can access.
create policy "Customers see own notifications" on public.ko_notifications for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Customers mark own notifications read" on public.ko_notifications;
-- Row-level security rule: restrict what each account can access.
create policy "Customers mark own notifications read" on public.ko_notifications for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists "Customers read own wishlist" on public.ko_wishlists;
-- Row-level security rule: restrict what each account can access.
create policy "Customers read own wishlist" on public.ko_wishlists for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists "Customers create own wishlist" on public.ko_wishlists;
-- Row-level security rule: restrict what each account can access.
create policy "Customers create own wishlist" on public.ko_wishlists for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists "Customers update own wishlist" on public.ko_wishlists;
-- Row-level security rule: restrict what each account can access.
create policy "Customers update own wishlist" on public.ko_wishlists for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- SECURE ORDER ENTRY POINT. Caller must be signed in; prices verified from ko_products.
-- Server-side business logic and secure order operations.
create or replace function public.ko_place_order(
  p_cart jsonb,
  p_customer jsonb,
  p_delivery text,
  p_promo text,
  p_notes text,
  p_request_key text
) returns jsonb
language plpgsql security definer set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_email text;
  v_item jsonb;
  v_id text;
  v_qty integer;
  v_product record;
  v_items jsonb := '[]'::jsonb;
  v_seen text[] := '{}'::text[];
  v_subtotal bigint := 0;
  v_discount bigint := 0;
  v_shipping bigint := 0;
  v_total bigint := 0;
  v_customer jsonb;
  v_promo text := upper(trim(coalesce(p_promo,'')));
  v_row public.ko_orders%rowtype;
begin
  if v_uid is null then raise exception 'Please sign in before placing an order'; end if;
  if p_request_key is null or p_request_key !~ '^[0-9a-f]{48}$' then raise exception 'Invalid order request key'; end if;
  select * into v_row from public.ko_orders where user_id=v_uid and request_key=p_request_key;
  if found then return to_jsonb(v_row); end if;
  if p_delivery not in ('standard','express') then raise exception 'Choose standard or express delivery'; end if;
  if v_promo not in ('','WELCOME10') then raise exception 'Discount code not recognised'; end if;
  if jsonb_typeof(p_cart) is distinct from 'array' then raise exception 'Invalid shopping bag'; end if;
  if jsonb_array_length(p_cart) < 1 or jsonb_array_length(p_cart) > 30 then raise exception 'Choose 1 to 30 products'; end if;
  if jsonb_typeof(p_customer) is distinct from 'object' then raise exception 'Customer details are required'; end if;
  select email into v_email from auth.users where id=v_uid;
  if v_email is null then raise exception 'Account email was not found'; end if;
  foreach v_id in array array['firstName','lastName','phone','street','city','province','postal'] loop
    if length(trim(coalesce(p_customer->>v_id,'')))=0 then raise exception 'Missing customer field: %', v_id; end if;
  end loop;
  if coalesce(p_customer->>'postal','') !~ '^[0-9]{4}$' then raise exception 'Invalid postal code'; end if;
  if length(p_customer->>'street')>140 or length(p_customer->>'city')>80 or length(p_customer->>'firstName')>60 or length(p_customer->>'lastName')>60 or length(p_customer->>'phone')>22 then raise exception 'Customer field too long'; end if;
  if p_customer->>'province' not in ('Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','North West','Northern Cape','Western Cape') then raise exception 'Choose a valid province'; end if;
  v_customer := jsonb_set(p_customer,'{email}',to_jsonb(v_email),true);
  if length(coalesce(p_notes,''))>500 then raise exception 'Delivery note too long'; end if;
  for v_item in select value from jsonb_array_elements(p_cart) loop
    v_id := v_item->>'id';
    if coalesce(v_item->>'qty','') !~ '^[0-9]{1,2}$' then raise exception 'Invalid quantity'; end if;
    v_qty := (v_item->>'qty')::integer;
    if v_id=any(v_seen) then raise exception 'Duplicate product in shopping bag'; end if;
    v_seen := array_append(v_seen,v_id);
    select id,name,image,price,max_quantity into v_product from public.ko_products where id=v_id;
    if not found then raise exception 'Product is no longer available: %', v_id; end if;
    if v_qty<1 or v_qty>v_product.max_quantity then raise exception 'Quantity not available for %',v_id; end if;
    v_items := v_items || jsonb_build_array(jsonb_build_object('id',v_product.id,'name',v_product.name,'image',v_product.image,'qty',v_qty,'unitPrice',v_product.price,'total',v_product.price*v_qty));
    v_subtotal := v_subtotal + v_product.price*v_qty;
  end loop;
  if v_promo='WELCOME10' then v_discount:=round(v_subtotal*0.1); end if;
  v_shipping := case when p_delivery='express' then 25000 when v_subtotal-v_discount >= 200000 then 0 else 15000 end;
  v_total := v_subtotal-v_discount+v_shipping;
  -- Limit accidental or abusive repeated orders; retry with the same request_key above remains idempotent.
  if (select count(*) from public.ko_orders where user_id=v_uid and created_at>now()-interval '1 hour') >= 10 then
    raise exception 'Too many recent orders. Please contact the store';
  end if;
  insert into public.ko_orders(user_id,request_key,customer,items,subtotal,discount,shipping,total,delivery,promo,notes,history)
  values(v_uid,p_request_key,v_customer,v_items,v_subtotal::integer,v_discount::integer,v_shipping::integer,v_total::integer,p_delivery,v_promo,coalesce(p_notes,''),jsonb_build_array(jsonb_build_object('status','Received','at',now(),'note','Order received. Awaiting store confirmation.')))
  returning * into v_row;
  return to_jsonb(v_row);
end;
$$;
revoke execute on function public.ko_place_order(jsonb,jsonb,text,text,text,text) from public;
grant execute on function public.ko_place_order(jsonb,jsonb,text,text,text,text) to authenticated;

-- When the owner updates order status in Supabase Table Editor/SQL, append history and notify customer.
-- Server-side business logic and secure order operations.
create or replace function public.ko_order_history() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status is distinct from old.status then
    new.history := coalesce(old.history,'[]'::jsonb) || jsonb_build_array(jsonb_build_object('status',new.status,'at',now(),'note','The store updated your order to '||new.status||'.'));
  end if;
  return new;
end;
$$;
drop trigger if exists ko_order_status_history on public.ko_orders;
-- Automatically run the associated database function.
create trigger ko_order_status_history before update of status on public.ko_orders
for each row execute function public.ko_order_history();

-- Server-side business logic and secure order operations.
create or replace function public.ko_order_notification() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if tg_op='INSERT' then
    insert into public.ko_notifications(user_id,order_number,title,message)
    values(new.user_id,new.order_number,'Order received','Order '||new.order_number||' was saved. We will confirm it before payment.');
  elsif new.status is distinct from old.status then
    insert into public.ko_notifications(user_id,order_number,title,message)
    values(new.user_id,new.order_number,'Order update','Your order '||new.order_number||' is now '||new.status||'.');
  end if;
  return new;
end;
$$;
drop trigger if exists ko_order_notifications on public.ko_orders;
-- Automatically run the associated database function.
create trigger ko_order_notifications after insert or update of status on public.ko_orders
for each row execute function public.ko_order_notification();

-- Optional: as store owner, change an order's status from Supabase SQL Editor:
-- update public.ko_orders set status='Confirmed' where order_number='KOT-YOURORDER';
-- No payment provider is connected: requests are NOT charged and shipping is NOT automatic.
