/* KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
 * File: slip.js
 * Purpose: PDF receipt creation, including purchased products, images and order totals.
 * Comments describe the main sections without changing application behaviour.
 */
/* Standalone PDF writer with embedded Unicode font and genuine clickable links.
 * Uses PDF 1.7 Type0 / CIDFontType2 text, ToUnicode and exact byte offsets.
 * No network, browser print dialog or third-party JavaScript dependency required.
 */
(function(root,factory){
  const node=typeof module!=='undefined'&&module.exports;
  const api=factory(node?require('./pdf-font.js'):root.KO_PDF_FONT);
  if(node)module.exports=api;else root.KOSlip=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(font){
  'use strict';
  // PDF helpers encode content as bytes and use actual byte offsets.
  const bytes=s=>new TextEncoder().encode(s);
  const join=arrays=>{const result=new Uint8Array(arrays.reduce((s,a)=>s+a.length,0));let offset=0;for(const a of arrays){result.set(a,offset);offset+=a.length;}return result;};
  const decode64=s=>typeof Buffer!=='undefined'?new Uint8Array(Buffer.from(s,'base64')):Uint8Array.from(atob(s),c=>c.charCodeAt(0));
  const money=n=>'R '+(n/100).toLocaleString('en-ZA',{minimumFractionDigits:2,maximumFractionDigits:2}).replace(/\u00a0/g,' ');
  const rgb=(r,g,b)=>[r/255,g/255,b/255].map(v=>v.toFixed(3)).join(' ');
  const color={ink:rgb(23,37,35),green:rgb(27,85,66),muted:rgb(101,113,110),pale:rgb(240,244,235),white:'1 1 1',line:rgb(221,227,222)};
  const width=(text,size)=>[...String(text)].reduce((n,c)=>n+(font.metrics[c.codePointAt(0)]||font.metrics[63])[1]*size/font.units,0);
  // Assemble a PDF with purchased items, image thumbnails, totals and tracking details.
  function build(order,trackingUrl,itemImages=[]){
    if(!order?.customer||!Array.isArray(order.items)||!/^https?:|^file:/.test(trackingUrl))throw Error('A valid order and tracking link are required.');
    const objects=[],reserve=()=>{objects.push(null);return objects.length;};
    const put=(id,body)=>{objects[id-1]=typeof body==='string'?bytes(body):body;};
    const add=body=>{const id=reserve();put(id,body);return id;};
    const stream=data=>join([bytes('<< /Length '+data.length+' >>\nstream\n'),data,bytes('\nendstream')]);
    const catalogId=reserve(),pagesId=reserve(),fontId=reserve(),cidId=reserve(),descriptorId=reserve(),fileId=reserve(),unicodeId=reserve();
    const glyphs=new Map(),pages=[];
    let current,y;
    const hex=text=>[...String(text)].map(c=>{const cp=c.codePointAt(0),m=font.metrics[cp]||font.metrics[63];glyphs.set(m[0],{cp:font.metrics[cp]?cp:63,w:Math.round(m[1]*1000/font.units)});return m[0].toString(16).padStart(4,'0');}).join('');
    const draw=(text,x,at,size=10,fill=color.ink)=>{current.ops.push(`BT /F1 ${size} Tf ${fill} rg 1 0 0 1 ${x.toFixed(2)} ${at.toFixed(2)} Tm <${hex(text)}> Tj ET`);};
    const box=(x,at,w,h,fill)=>current.ops.push(`${fill} rg ${x} ${at} ${w} ${h} re f`);
    const line=(at)=>current.ops.push(`${color.line} RG .6 w 42 ${at} m 553 ${at} l S`);
    function newPage(){
      current={id:reserve(),ops:[],links:[]};pages.push(current);
      box(0,736,595.28,106,color.green);
      draw('KO.tech',42,786,28,color.white);draw('ORDER SLIP',42,761,9,color.white);
      draw(order.id,330,793,11,color.white);
      draw(new Date(order.created).toLocaleDateString('en-ZA',{year:'numeric',month:'long',day:'numeric'}),330,773,9,color.white);
      draw(order.demo?'BROWSER PREVIEW':'ORDER REQUEST',330,754,8,color.white);
      y=708;
    }
    function ensure(height){if(y-height<55)newPage();}
    function wrap(text,size,maxWidth){
      const lines=[];
      for(const paragraph of String(text??'').split(/\r?\n/)){
        let buffer='';
        for(const word of paragraph.split(/\s+/)){
          if(width(word,size)>maxWidth){
            if(buffer){lines.push(buffer);buffer='';}
            for(const c of word){if(width(buffer+c,size)>maxWidth){lines.push(buffer);buffer='';}buffer+=c;}
          }else if(width(buffer+(buffer?' ':'')+word,size)>maxWidth){lines.push(buffer);buffer=word;}else buffer+=(buffer?' ':'')+word;
        }
        lines.push(buffer);
      }
      return lines;
    }
    function para(text,size=10,fill=color.ink,maxWidth=511,x=42){for(const value of wrap(text,size,maxWidth)){ensure(size+7);draw(value,x,y,size,fill);y-=size+6;}}
    function section(title){ensure(42);y-=10;draw(title.toUpperCase(),42,y,8,color.green);y-=20;}
    newPage();
    para('Thank you, '+order.customer.firstName+'.',20);
    para(order.demo?'This preview was saved on your browser. No real order or payment was made.':'Your order request is recorded. The store will confirm availability and payment.',9,color.muted);
    y-=7;line(y);y-=23;
    const customer=order.customer;
    const left=[customer.firstName+' '+customer.lastName,customer.email,customer.phone];
    const right=[customer.street+(customer.apartment?', '+customer.apartment:''),customer.city+', '+customer.province+' '+customer.postal,'South Africa | '+(order.delivery==='express'?'Express':'Standard')+' delivery'];
    const columns=[left,right].map(values=>values.flatMap(value=>wrap(value,9,240)));
    ensure(Math.max(...columns.map(col=>col.length))*15+35);
    draw('CUSTOMER DETAILS',42,y,8,color.green);draw('DELIVERY ADDRESS',310,y,8,color.green);y-=22;
    columns.forEach((col,i)=>col.forEach((value,n)=>draw(value,i?310:42,y-n*15,9)));
    y-=Math.max(...columns.map(col=>col.length))*15+4;
    if(order.notes){y-=4;para('Delivery note: '+order.notes,9,color.muted);}
    section('Products in your order ('+order.items.reduce((n,item)=>n+Number(item.qty||0),0)+' items)');
    function tableHeader(){ensure(48);box(42,y-14,511,26,color.pale);draw('PRODUCT / PHOTO',51,y-5,8,color.green);draw('QTY',343,y-5,8,color.green);draw('UNIT PRICE',385,y-5,8,color.green);draw('TOTAL',506,y-5,8,color.green);y-=35;}
    tableHeader();
    for(let index=0;index<order.items.length;index++){
      const item=order.items[index];
      const rows=wrap(item.name,9,210),height=Math.max(64,rows.length*14+29);
      if(y-height<70){newPage();tableHeader();}
      const thumb=itemImages[index];
      if(thumb?.data instanceof Uint8Array&&thumb.data.length){
        current.ops.push(`q 48 0 0 48 51 ${ (y-49).toFixed(2) } cm /Im${index+1} Do Q`);
      }else{
        box(51,y-49,48,48,color.pale);
        draw('KO TECH',56,y-25,7,color.muted);
      }
      rows.forEach((text,i)=>draw(text,111,y-4-i*14,9));
      draw(String(item.id||''),111,y-5-rows.length*14,7,color.muted);
      draw(String(item.qty),354,y-4,9);
      const unit=money(item.unitPrice),total=money(item.total);
      draw(unit,451-width(unit,9),y-4,9);draw(total,543-width(total,9),y-4,9);
      y-=height;line(y+7);y-=5;
    }
    ensure(142);y-=7;
    for(const [label,value] of [['Subtotal',money(order.subtotal)],...(order.discount?[['Discount (WELCOME10)','- '+money(order.discount)]]:[]),['Delivery',order.shipping?money(order.shipping):'Free']]){
      draw(label,320,y,9,color.muted);draw(value,543-width(value,10),y,10);y-=23;
    }
    box(310,y-15,243,36,color.pale);draw('TOTAL',322,y-2,10,color.green);const total=money(order.total);draw(total,541-width(total,14),y-2,14,color.green);y-=42;
    para('Payment: '+order.paymentStatus+' | '+order.paymentMethod,9,color.muted);
    para('Order status: '+order.status,9,color.muted);
    ensure(155);
    section('Your private tracking link');
    box(42,y-17,210,34,color.green);draw('OPEN ORDER TRACKING',54,y-4,10,color.white);
    current.links.push({rect:[42,y-17,252,y+17],url:trackingUrl});y-=43;
    const linkLines=wrap(trackingUrl,8,511);
    for(const text of linkLines){ensure(16);draw(text,42,y,8,color.green);current.links.push({rect:[42,y-2,Math.min(553,42+width(text,8)),y+9],url:trackingUrl});y-=14;}
    y-=6;para('Private access code: '+order.token,8,color.muted);
    para('Keep this link and access code private. They give access to your order details.',8,color.muted);
    if(order.demo)para('Preview tracking works only in the same browser and at the same site address used at checkout.',8,color.muted);
    y-=5;
    para('This document is an order slip, not a tax invoice or proof of payment. No payment is collected by this website. Contact the store with your order number for changes or assistance.',8,color.muted);
    const imageRefs=[];
    for(let i=0;i<order.items.length;i++){
      const im=itemImages[i];
      if(!im?.data?.length||!Number.isInteger(im.width)||!Number.isInteger(im.height))continue;
      // Thumbnails are converted by the browser to baseline RGB JPEG before embedding.
      const header=bytes(`<< /Type /XObject /Subtype /Image /Width ${im.width} /Height ${im.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.data.length} >>\nstream\n`);
      imageRefs.push(`/Im${i+1} ${add(join([header,im.data,bytes('\nendstream')]))} 0 R`);
    }
    const imageResources=imageRefs.length?' /XObject << '+imageRefs.join(' ')+' >>':'';
    for(let i=0;i<pages.length;i++){
      current=pages[i];line(45);draw('KO TECH | ST10518194 | Keep your tracking link private',42,29,7,color.muted);draw('Page '+(i+1)+' of '+pages.length,492,29,7,color.muted);
      const content=add(stream(bytes(current.ops.join('\n'))));
      const annots=current.links.map(link=>add('<< /Type /Annot /Subtype /Link /Rect ['+link.rect.join(' ')+'] /Border [0 0 0] /A << /S /URI /URI ('+link.url.replace(/([\\()])/g,'\\$1')+') >> >>'));
      put(current.id,`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595.28 841.89] /Resources << /Font << /F1 ${fontId} 0 R >>${imageResources} >> /Contents ${content} 0 R /Annots [${annots.map(id=>id+' 0 R').join(' ')}] >>`);
    }
    const fontBytes=decode64(font.base64);
    put(fileId,join([bytes(`<< /Length ${fontBytes.length} /Length1 ${fontBytes.length} >>\nstream\n`),fontBytes,bytes('\nendstream')]));
    const scale=n=>Math.round(n*1000/font.units);
    put(descriptorId,`<< /Type /FontDescriptor /FontName /DejaVuSans /Flags 32 /FontBBox [${font.bbox.map(scale).join(' ')}] /ItalicAngle 0 /Ascent ${scale(font.ascent)} /Descent ${scale(font.descent)} /CapHeight 729 /StemV 80 /FontFile2 ${fileId} 0 R >>`);
    put(cidId,`<< /Type /Font /Subtype /CIDFontType2 /BaseFont /DejaVuSans /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor ${descriptorId} 0 R /CIDToGIDMap /Identity /DW 600 /W [${[...glyphs].sort((a,b)=>a[0]-b[0]).map(([gid,v])=>gid+' ['+v.w+']').join(' ')}] >>`);
    let cmap='/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <ffff>\nendcodespacerange\n';
    const glyphList=[...glyphs];
    for(let offset=0;offset<glyphList.length;offset+=100){const list=glyphList.slice(offset,offset+100);cmap+=list.length+' beginbfchar\n'+list.map(([gid,v])=>{const code=v.cp<=65535?v.cp.toString(16).padStart(4,'0'):[0xD800+((v.cp-65536)>>10),0xDC00+((v.cp-65536)&1023)].map(n=>n.toString(16)).join('');return '<'+gid.toString(16).padStart(4,'0')+'> <'+code+'>';}).join('\n')+'\nendbfchar\n';}
    cmap+='endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';put(unicodeId,stream(bytes(cmap)));
    put(fontId,`<< /Type /Font /Subtype /Type0 /BaseFont /DejaVuSans /Encoding /Identity-H /DescendantFonts [${cidId} 0 R] /ToUnicode ${unicodeId} 0 R >>`);
    put(pagesId,`<< /Type /Pages /Count ${pages.length} /Kids [${pages.map(p=>p.id+' 0 R').join(' ')}] >>`);
    put(catalogId,`<< /Type /Catalog /Pages ${pagesId} 0 R >>`);
    const chunks=[bytes('%PDF-1.7\n%KO TECH PDF\n')],offsets=[0];let length=chunks[0].length;
    objects.forEach((body,i)=>{offsets.push(length);const chunk=join([bytes((i+1)+' 0 obj\n'),body,bytes('\nendobj\n')]);chunks.push(chunk);length+=chunk.length;});
    const xref='xref\n0 '+(objects.length+1)+'\n0000000000 65535 f \n'+offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<< /Size ${objects.length+1} /Root ${catalogId} 0 R >>\nstartxref\n${length}\n%%EOF\n`;
    chunks.push(bytes(xref));return join(chunks);
  }
  async function loadProductImage(path){
    if(typeof document==='undefined'||typeof Image==='undefined'||!/^Images\/[a-zA-Z0-9/_\-.]+$/.test(String(path||'')))return null;
    return new Promise(resolve=>{
      let finished=false;
      const finish=value=>{if(finished)return;finished=true;clearTimeout(timer);resolve(value);};
      const timer=setTimeout(()=>finish(null),6500);
      const img=new Image();
      img.onload=()=>{
        try{
          if(!img.naturalWidth||!img.naturalHeight)return finish(null);
          const side=160,canvas=document.createElement('canvas');canvas.width=side;canvas.height=side;
          const ctx=canvas.getContext('2d');if(!ctx)return finish(null);
          ctx.fillStyle='#ffffff';ctx.fillRect(0,0,side,side);
          const ratio=Math.min(side/img.naturalWidth,side/img.naturalHeight);
          const w=img.naturalWidth*ratio,h=img.naturalHeight*ratio;
          ctx.drawImage(img,(side-w)/2,(side-h)/2,w,h);
          const jpeg=canvas.toDataURL('image/jpeg',.78).split(',')[1];
          finish({data:decode64(jpeg),width:side,height:side});
        }catch{finish(null);}
      };
      img.onerror=()=>finish(null);
      // The image files ship with this site. No external image service is required.
      img.src=new URL(path.split('/').map(encodeURIComponent).join('/'),document.baseURI).href;
    });
  }
  // Create and download the PDF from the current order in the browser.
  async function download(order,url){
    if(!order?.items?.length)throw Error('The order must contain products before its PDF can be downloaded.');
    const itemImages=await Promise.all(order.items.map(item=>{
      const stored=typeof window!=='undefined'?window.KO?.product?.(item.id):null;
      return loadProductImage(stored?.image||item.image);
    }));
    const data=build(order,url,itemImages),blob=new Blob([data],{type:'application/pdf'}),href=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=href;a.download='KO-TECH-Order-'+order.id+'.pdf';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(href),60000);
  }
  return {build,download};
});
