/* KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
 * File: cloud.js
 * Purpose: Supabase adapter for account authentication, orders, wishlist and notifications.
 * Comments describe the main sections without changing application behaviour.
 */
/* KO TECH cloud adapter: Supabase Auth, protected orders, profile and notifications. */
(function () {
  'use strict';
  let client=null;
  const settings=window.KO_CLOUD_CONFIG||{};
  const configured=Boolean(/^https:\/\/[^/]+\.supabase\.co\/?$/.test(settings.url||'') && /^(sb_publishable_|eyJ)/.test(settings.publishableKey||''));
  // Surface Supabase API errors with readable messages.
  function fail(error){if(error)throw Error(error.message||String(error));}
  // Prevent secure account calls until a backend is configured.
  function requireClient(){if(!client)throw Error('Secure accounts are not connected yet. Configure Supabase in js/backend-config.js.');return client;}
  // Expose only the customer details needed by the frontend.
  function userView(u){return u?{id:u.id,email:u.email||'',name:u.user_metadata?.name||u.email?.split('@')[0]||'Customer',phone:u.user_metadata?.phone||''}:null;}
  // Convert database column names to the interface order format.
  function normaliseOrder(row){
    if(!row)return null;
    return {id:row.order_number,dbId:row.id,token:'',created:row.created_at,customer:row.customer,items:row.items,subtotal:row.subtotal,discount:row.discount,shipping:row.shipping,total:row.total,delivery:row.delivery,promo:row.promo,currency:'ZAR',notes:row.notes,status:row.status,paymentStatus:row.payment_status,paymentMethod:row.payment_method,history:row.history||[],demo:false};
  }
  // All account/order operations below use Supabase Auth and row-level security.
  const KOCloud={
    configured,
    async init(){
      if(!configured)return false;
      if(!window.supabase?.createClient)throw Error('Could not load the secure account library. Check your internet connection and reload.');
      client=window.supabase.createClient(settings.url.replace(/\/$/,''),settings.publishableKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
      client.auth.onAuthStateChange((event)=>{if(event==='PASSWORD_RECOVERY')sessionStorage.setItem('ko_reset_pending','1');});
      return true;
    },
    async user(){const {data,error}=await requireClient().auth.getUser();if(error&&error.name!=='AuthSessionMissingError')fail(error);return userView(data?.user);},
    async register({name,email,password,phone=''}){
      const {data,error}=await requireClient().auth.signUp({email,password,options:{data:{name,phone},emailRedirectTo:new URL('Login.html',location.href).href}});fail(error);
      return {user:userView(data.user),needsConfirmation:!data.session};
    },
    async login(email,password){const {data,error}=await requireClient().auth.signInWithPassword({email,password});fail(error);return userView(data.user);},
    async logout(){const {error}=await requireClient().auth.signOut();fail(error);},
    async sendRecovery(email){const {error}=await requireClient().auth.resetPasswordForEmail(email,{redirectTo:new URL('Forgot-Password.html',location.href).href});fail(error);},
    async changePassword(password){const {error}=await requireClient().auth.updateUser({password});fail(error);},
    async updateProfile(name,phone){const {data,error}=await requireClient().auth.updateUser({data:{name,phone}});fail(error);return userView(data.user);},
    async placeOrder(payload){
      const {data,error}=await requireClient().rpc('ko_place_order',{p_cart:payload.cart,p_customer:payload.customer,p_delivery:payload.delivery,p_promo:payload.promo||'',p_notes:payload.notes||'',p_request_key:payload.requestKey});fail(error);
      return normaliseOrder(data);
    },
    async orders(){const {data,error}=await requireClient().from('ko_orders').select('*').order('created_at',{ascending:false}).limit(100);fail(error);return (data||[]).map(normaliseOrder);},
    async order(number){const {data,error}=await requireClient().from('ko_orders').select('*').eq('order_number',number).maybeSingle();fail(error);if(!data)throw Error('Order not found in this account. Please sign in with the account that placed it.');return normaliseOrder(data);},
    async notifications(){const {data,error}=await requireClient().from('ko_notifications').select('id,title,message,order_number,created_at,read_at').order('created_at',{ascending:false}).limit(50);fail(error);return data||[];},
    async markRead(id){const {error}=await requireClient().from('ko_notifications').update({read_at:new Date().toISOString()}).eq('id',id);fail(error);},
    async wishlist(){const {data,error}=await requireClient().from('ko_wishlists').select('product_ids').maybeSingle();fail(error);return data?.product_ids||[];},
    async saveWishlist(ids){const current=await this.user();if(!current)throw Error('Please sign in to save a wishlist across devices.');const {error}=await requireClient().from('ko_wishlists').upsert({user_id:current.id,product_ids:ids},{onConflict:'user_id'});fail(error);},
  };
  window.KOCloud=KOCloud;
})();
