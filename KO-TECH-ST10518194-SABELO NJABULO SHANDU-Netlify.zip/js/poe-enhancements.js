/* KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
 * File: poe-enhancements.js
 * Purpose: Form feedback and accessible input validation for the POE rubric.
 * Comments describe the main sections without changing application behaviour.
 */
/* WEDE5020 Part 3: accessible inline feedback for dynamically rendered enquiry and contact forms. */
(() => {
  'use strict';
  const allowed=new Set(['contact-form','enquiry-form']);
  // Only enhance the two public customer forms.
  function isAllowed(el){return !!el?.form && allowed.has(el.form.id);}
  // Choose a useful message for each native HTML validity state.
  function errorText(el){
    if(el.validity.valueMissing)return 'This field is required.';
    if(el.validity.typeMismatch)return el.type==='email'?'Enter a valid email address.':'Enter a valid value.';
    if(el.validity.patternMismatch)return el.type==='tel'?'Enter a valid contact number (7–22 characters).':'Check the requested format.';
    if(el.validity.tooShort)return `Please enter at least ${el.minLength} characters.`;
    if(el.validity.tooLong)return `Use no more than ${el.maxLength} characters.`;
    if(el.validity.rangeOverflow||el.validity.rangeUnderflow)return 'Enter a value in the allowed range.';
    if(el.validity.customError||el.validity.badInput)return el.validationMessage;
    return el.validity.valid?'':el.validationMessage;
  }
  // Attach an accessible error message to the selected field.
  function show(el,showOnlyAfterTouch=true){
    if(!isAllowed(el)||!el.willValidate)return;
    const wrap=el.closest('label,.field,fieldset')||el.parentElement;
    if(!wrap)return;
    const id=(el.id||el.name)+'-feedback';
    let feedback=wrap.querySelector('[data-validation-for="'+CSS.escape(el.name)+'"]');
    if(!feedback){feedback=document.createElement('small');feedback.className='inline-field-feedback';feedback.id=id;feedback.dataset.validationFor=el.name;feedback.setAttribute('aria-live','polite');wrap.append(feedback);}
    const touched=el.dataset.touched==='true';
    if(showOnlyAfterTouch&&!touched)return;
    const error=errorText(el);
    feedback.textContent=error;
    el.setAttribute('aria-invalid',String(!!error));
    if(error)el.setAttribute('aria-describedby',id);
    else if(el.getAttribute('aria-describedby')===id)el.removeAttribute('aria-describedby');
    feedback.classList.toggle('is-error',!!error);
  }
  document.addEventListener('focusout',e=>{if(isAllowed(e.target)){e.target.dataset.touched='true';show(e.target);}},true);
  document.addEventListener('input',e=>{if(isAllowed(e.target))show(e.target);});
  document.addEventListener('change',e=>{if(isAllowed(e.target))show(e.target);});
  document.addEventListener('invalid',e=>{if(isAllowed(e.target)){e.target.dataset.touched='true';show(e.target,false);}},true);
})();
