/* KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
 * File: backend-config.js
 * Purpose: Public Supabase connection settings (never put database secrets here).
 * Comments describe the main sections without changing application behaviour.
 */
/* KO TECH cloud settings. Configure only the PUBLIC Supabase project URL and publishable/anon key.
   NEVER paste a service_role/secret key here. See SETUP-ACCOUNTS.md. */
// Set your project URL and public key before deploying live accounts.
window.KO_CLOUD_CONFIG = {
  url: '',
  publishableKey: ''
};
