/* KO TECH | Student: ST10518194 NJABULO SABELO SHANDU
 * File: core.js
 * Purpose: Reusable validation, order price calculations, search and utility functions.
 * Comments describe the main sections without changing application behaviour.
 */
/* Shared business rules. All money is stored as integer cents. */
(function(root, factory) {
  const api = factory(typeof module !== 'undefined' && module.exports ? require('./catalog.js') : root.KO_PRODUCTS);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.KO = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function(products) {
  'use strict';
  const provinces = ['Eastern Cape','Free State','Gauteng','KwaZulu-Natal','Limpopo','Mpumalanga','North West','Northern Cape','Western Cape'];
  // These status labels match the stages on the tracking page.
  const statuses = ['Received', 'Confirmed', 'Packed', 'Shipped', 'Delivered'];
  const product = id => products.find(p => p.id === id);
  const money = cents => new Intl.NumberFormat('en-ZA', {style:'currency',currency:'ZAR'}).format(cents / 100);
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  // Ignore invalid product IDs and combine duplicate cart entries safely.
  function normaliseCart(cart) {
    if (!Array.isArray(cart)) return [];
    const entries = new Map();
    for (const row of cart.slice(0, 100)) {
      const p = product(row?.id), qty = Number(row?.qty);
      if (p && Number.isInteger(qty) && qty > 0) entries.set(p.id, Math.min(p.maxQuantity, (entries.get(p.id) || 0) + qty));
    }
    return [...entries].map(([id, qty]) => ({id, qty}));
  }
  // Recalculate totals in cents, including delivery charges and promotions.
  function quote(cart, delivery='standard', promo='') {
    const rows = normaliseCart(cart);
    if (!['standard','express'].includes(delivery)) throw new Error('Choose a valid delivery option.');
    const code = String(promo).trim().toUpperCase();
    if (code && code !== 'WELCOME10') throw new Error('That code is not recognised. Try WELCOME10.');
    const items = rows.map(row => {const p = product(row.id);return {id:p.id,name:p.name,image:p.image,qty:row.qty,unitPrice:p.price,total:p.price*row.qty};});
    const subtotal = items.reduce((sum, row) => sum + row.total, 0);
    const discount = code ? Math.round(subtotal * .1) : 0;
    const shipping = !items.length ? 0 : delivery === 'express' ? 25000 : subtotal-discount >= 200000 ? 0 : 15000;
    return {items,subtotal,discount,shipping,total:subtotal-discount+shipping,delivery,promo:code,currency:'ZAR'};
  }
  // Clean and normalize text input before it enters an order.
  function clean(value, label, max=100, min=1) {
    if (typeof value !== 'string') throw new Error(label + ' is required.');
    const v = value.trim().replace(/\s+/g,' ');
    if (v.length < min || v.length > max || /[\u0000-\u001f\u007f]/.test(v)) throw new Error('Enter a valid '+label.toLowerCase()+'.');
    return v;
  }
  // Check email input used by registration and checkout.
  function email(value) {
    const v = clean(value, 'Email address', 254).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new Error('Enter a valid email address.');
    return v;
  }
  // Validate the checkout recipient and delivery fields.
  function customer(data) {
    if (!data || typeof data !== 'object') throw new Error('Your details are required.');
    const c={firstName:clean(data.firstName,'First name',60),lastName:clean(data.lastName,'Last name',60),email:email(data.email),phone:clean(data.phone,'Phone number',22),street:clean(data.street,'Street address',140),apartment:String(data.apartment||'').trim().slice(0,80),city:clean(data.city,'City',80),province:clean(data.province,'Province',30),postal:clean(data.postal,'Postal code',4)};
    if (!/^(?:\+27|0)[\d\s()-]{8,16}$/.test(c.phone) || ![10,11].includes(c.phone.replace(/\D/g,'').length)) throw new Error('Enter a South African phone number, e.g. 082 123 4567.');
    if (!provinces.includes(c.province)) throw new Error('Choose a South African province.');
    if (!/^\d{4}$/.test(c.postal)) throw new Error('Enter a four-digit postal code.');
    return c;
  }
  // Create a link back to the order tracking page.
  function trackingUrl(order, base) {
    const url = new URL('Track-Order.html', base);
    url.hash = new URLSearchParams({order:order.id,key:order.token}).toString();
    return url.href;
  }
  // Find and sort catalogue products using customer filters.
  function filterProducts({q='',category='',sort='featured',sale=false,min=0,max=Infinity,newOnly=false}={}) {
    const term=String(q).trim().toLowerCase();
    const list=products.filter(p=>(!category||p.category===category)&&(!sale||p.discount>0)&&(!newOnly||p.isNew)&&p.price>=min*100&&p.price<=max*100&&(!term||(p.name+' '+p.category+' '+p.id).toLowerCase().includes(term)));
    const comparators={'price-asc':(a,b)=>a.price-b.price,'price-desc':(a,b)=>b.price-a.price,name:(a,b)=>a.name.localeCompare(b.name),sale:(a,b)=>b.discount-a.discount,featured:(a,b)=>b.rank-a.rank};
    return list.sort(comparators[sort]||comparators.featured);
  }
  return {products,product,provinces,statuses,money,escape,normaliseCart,quote,clean,email,customer,trackingUrl,filterProducts};
});
