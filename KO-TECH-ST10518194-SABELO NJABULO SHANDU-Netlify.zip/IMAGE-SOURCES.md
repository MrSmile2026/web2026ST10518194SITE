# Image attribution and SEO notes

The original uploaded coursework archive included images but no source URLs or license metadata. I retained the existing images and renamed the assets using URL-safe filenames in previous iterations. The source of each photo **cannot be independently verified from the ZIP**, so it is not appropriate to invent a Harvard citation or claim reuse rights.

For your final university submission: locate the website/creator for any image you downloaded and record its title, author/organisation, URL, license (if provided), and date accessed. Include the attribution in this file and your references. Use your own original images if source permissions cannot be established.

The `Images/gallery/` files support the glossy Gallery. Product images under `Images/{category}/` support catalogue cards, PDF slips and product details. Descriptive `alt` text is attached to product cards and Gallery items from their catalogue titles.
