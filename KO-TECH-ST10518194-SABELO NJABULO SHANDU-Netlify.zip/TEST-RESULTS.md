# KO TECH — automated static verification

Validated on 1 November 2026. These checks examine source code and referenced assets. They are **not** equivalent to a real Netlify deployment, sent email, Supabase service test or browser interaction test.

| Check | Result | Detail |
|---|---|---|
| URL-safe filenames | PASS | [] |
| JavaScript syntax, all source files | PASS | [] |
| All HTML local links/assets | PASS | 336 references, missing: [] |
| All page SEO metadata | PASS | Pages: 24, missing: [] |
| HTML img alt attributes | PASS | Violations: [] |
| Catalogue image assets | PASS | 62 checked, missing: [] |
| Gallery image assets | PASS | 6 checked, missing: [] |
| Glossy Gallery / Lightbox | PASS |  |
| Interactive map | PASS |  |
| Live product search | PASS |  |
| Contact + Enquiry validation | PASS |  |
| Contact + Enquiry Netlify form definitions | PASS |  |
| PDF with purchased items | PASS |  |
| Supabase auth & account instructions | PASS |  |
| README/Changelog/References | PASS |  |
| Netlify deploy config | PASS |  |
| Supabase public config requires user setup | PASS | /* KO TECH cloud settings. Configure only the PUBLIC Supabase project URL and publishable/anon key.    NEVER paste a ser |

## Manual verification still needed

- Open the site in VS Code Live Server or after Netlify upload; check navigation and mobile responsiveness.
- Enable Netlify Forms and set up an email notification recipient, then confirm messages and email arrive.
- Create real GitHub commits, connect Supabase, and test accounts/order status as needed.
- Verify image attributions and original Part 2 feedback.

Chromium automated navigation was unavailable in this execution environment (navigation was blocked by administrator policy), so browser click-test success is not claimed.
